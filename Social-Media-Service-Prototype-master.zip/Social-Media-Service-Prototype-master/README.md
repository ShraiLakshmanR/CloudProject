# Social-Media-Service-Prototype
Social Media Service like Facebook prototype with Distributed Servers, Consistent Hashing, Load Balancing, Scalability and Fault Tolerance aspects.
A Full-Stack Social Media Service prototype, using the Flask Web-Framework in Python with MySQL back-end. Used Round-Robin algorithm for Load Balancing and consistent Hashing for distributed data storage. Deployed the application on Docker platform to provide virtualization, security and scalability. 

Refer to ReadMe.txt for specific information about commands
Refer to facebook-like_Service_Report for complete design and implementation details.
