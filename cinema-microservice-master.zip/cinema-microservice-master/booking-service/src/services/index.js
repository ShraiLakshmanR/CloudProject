const paymentService = require('./payment.service')
const notificationService = require('./notification.service')

module.exports = Object.assign({}, {paymentService, notificationService})
