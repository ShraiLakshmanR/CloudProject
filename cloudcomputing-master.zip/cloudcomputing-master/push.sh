
sudo scp -i ~/FirstKey.pem /home/guri/Documents/cloudcomputing/* ubuntu@18.188.26.53:/home/ubuntu/cloudcomputing
sudo scp -i ~/FirstKey.pem /home/guri/Documents/cloudcomputing/* ubuntu@18.221.68.162:/home/ubuntu/cloudcomputing
sudo scp -i ~/FirstKey.pem /home/guri/Documents/cloudcomputing/* ubuntu@18.219.17.156:/home/ubuntu/cloudcomputing
sudo scp -i ~/FirstKey.pem /home/guri/Documents/cloudcomputing/* ubuntu@13.59.124.206:/home/ubuntu/cloudcomputing

