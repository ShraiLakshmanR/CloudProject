# Cloud-Computing-Projects

A set of Cloud based python scripts to automate processes in AWS based on specific requirements
