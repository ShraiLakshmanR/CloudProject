# ProctorManagementSystem
•	A fully functional website for student proctor communication. 

•	It’s a platform to register for new courses for students.

•	Platform for Proctors to notify students of their attendance status and marks.
